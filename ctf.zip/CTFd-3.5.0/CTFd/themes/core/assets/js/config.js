export default {
  urlRoot: "",
  csrfNonce: "",
  userMode: ""
};
